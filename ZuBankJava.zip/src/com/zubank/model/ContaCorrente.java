package com.zubank.model;

public class ContaCorrente extends Conta {
    public ContaCorrente(int numero, Cliente cliente, double saldoInicial) {
        super(numero, cliente, saldoInicial);
    }
}
