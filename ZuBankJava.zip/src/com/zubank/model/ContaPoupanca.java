package com.zubank.model;

public class ContaPoupanca extends Conta {
    public ContaPoupanca(int numero, Cliente cliente, double saldoInicial) {
        super(numero, cliente, saldoInicial);
    }
}
