package com.zubank.model;

public enum TipoTransacao {
    ABERTURA, DEPOSITO, SAQUE, TRANSFERENCIA, INVESTIMENTO, EMPRESTIMO, FINANCIAMENTO
}
